﻿CREATE DATABASE CLINICARE_GROUP2;
GO

USE CLINICARE_GROUP2;
GO

/* =========================================================
   1. BẢNG DANH MỤC
   ========================================================= */

CREATE TABLE Vai_tro (
    ma_vai_tro VARCHAR(10) PRIMARY KEY,
    ten_vai_tro NVARCHAR(50) NOT NULL
);
GO

CREATE TABLE Trang_thai (
    ma_trang_thai VARCHAR(10) PRIMARY KEY,
    ten_trang_thai NVARCHAR(50) NOT NULL
);
GO

/* =========================================================
   2. BẢNG KHOA
   ========================================================= */

CREATE TABLE Khoa (
    ma_khoa VARCHAR(10) PRIMARY KEY,
    ten_khoa NVARCHAR(100) NOT NULL,
    ma_bac_si VARCHAR(10) NULL
);
GO

/* =========================================================
   3. TÀI KHOẢN VÀ THÔNG TIN NGƯỜI DÙNG
   ========================================================= */

CREATE TABLE Tai_khoan (
    ma_tai_khoan VARCHAR(10) PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    mat_khau VARCHAR(255) NOT NULL,
    ma_vai_tro VARCHAR(10) NOT NULL,
    FOREIGN KEY (ma_vai_tro) REFERENCES Vai_tro(ma_vai_tro)
);
GO

CREATE TABLE Thong_tin_nguoi_dung (
    ma_nguoi_dung VARCHAR(10) PRIMARY KEY,
    ho_ten NVARCHAR(100) NOT NULL,
    so_dien_thoai VARCHAR(15) NULL,
    gioi_tinh NVARCHAR(10) NULL,
    ngay_sinh DATE NULL,
    dia_chi NVARCHAR(MAX) NULL,
    cccd VARCHAR(20) NULL,
    chieu_cao FLOAT NULL,
    can_nang FLOAT NULL,
    nhom_mau VARCHAR(5) NULL,
    tien_su_benh NVARCHAR(MAX) NULL,
    di_ung NVARCHAR(MAX) NULL,
    ghi_chu NVARCHAR(MAX) NULL,
    ma_tai_khoan VARCHAR(10) NOT NULL,
    FOREIGN KEY (ma_tai_khoan) REFERENCES Tai_khoan(ma_tai_khoan)
);
GO

/* =========================================================
   4. BÁC SĨ
   ========================================================= */

CREATE TABLE Bac_si (
    ma_bac_si VARCHAR(10) PRIMARY KEY,
    ho_ten_bac_si NVARCHAR(100) NOT NULL,
    gioi_tinh NVARCHAR(10) NULL,
    ngay_sinh DATE NULL,
    so_dien_thoai VARCHAR(15) NULL,
    email VARCHAR(100) NULL,
    chuc_danh NVARCHAR(100) NOT NULL,
    chuyen_khoa NVARCHAR(100) NULL,
    so_nam_kinh_nghiem INT NULL,
    dia_chi NVARCHAR(MAX) NULL,
    mo_ta_kinh_nghiem NVARCHAR(MAX) NULL,
    ma_khoa VARCHAR(10) NOT NULL,
    FOREIGN KEY (ma_khoa) REFERENCES Khoa(ma_khoa)
);
GO

ALTER TABLE Khoa
ADD CONSTRAINT FK_Khoa_BacSi
FOREIGN KEY (ma_bac_si) REFERENCES Bac_si(ma_bac_si);
GO

/* =========================================================
   5. PHÒNG KHÁM
   ========================================================= */

CREATE TABLE Phong_kham (
    ma_phong VARCHAR(10) PRIMARY KEY,
    ten_phong NVARCHAR(100) NOT NULL,
    ma_khoa VARCHAR(10) NOT NULL,
    FOREIGN KEY (ma_khoa) REFERENCES Khoa(ma_khoa)
);
GO

/* =========================================================
   6. CẤU HÌNH GIỜ LÀM BÁC SĨ
   ========================================================= */

CREATE TABLE Cau_hinh_gio_lam_bac_si (
    ma_cau_hinh VARCHAR(10) PRIMARY KEY,
    ma_bac_si VARCHAR(10) NOT NULL,
    ngay_hieu_luc DATE NOT NULL,
    gio_sang_bat_dau TIME NOT NULL,
    gio_sang_ket_thuc TIME NOT NULL,
    gio_chieu_bat_dau TIME NOT NULL,
    gio_chieu_ket_thuc TIME NOT NULL,
    trang_thai NVARCHAR(20) NOT NULL DEFAULT N'Đang áp dụng',
    ngay_tao DATETIME NOT NULL DEFAULT GETDATE(),
    ngay_cap_nhat DATETIME NULL,
    ghi_chu NVARCHAR(255) NULL,

    CONSTRAINT FK_CauHinh_BacSi
        FOREIGN KEY (ma_bac_si) REFERENCES Bac_si(ma_bac_si),

    CONSTRAINT CHK_CauHinh_GioSang
        CHECK (gio_sang_ket_thuc > gio_sang_bat_dau),

    CONSTRAINT CHK_CauHinh_GioChieu
        CHECK (gio_chieu_ket_thuc > gio_chieu_bat_dau),

    CONSTRAINT CHK_CauHinh_TrangThai
        CHECK (trang_thai IN (N'Đang áp dụng', N'Hết hiệu lực'))
);
GO

CREATE UNIQUE INDEX UIX_CauHinh_BacSi_NgayHieuLuc
ON Cau_hinh_gio_lam_bac_si(ma_bac_si, ngay_hieu_luc);
GO

/* =========================================================
   7. KHUNG GIỜ KHÁM
   ========================================================= */

CREATE TABLE Khung_gio_kham (
    ma_khung_gio VARCHAR(10) PRIMARY KEY,
    thoi_luong_phut INT NOT NULL CONSTRAINT DF_KhungGio_ThoiLuong DEFAULT 30,
    ma_bac_si VARCHAR(10) NOT NULL,
    FOREIGN KEY (ma_bac_si) REFERENCES Bac_si(ma_bac_si),
    CONSTRAINT CHK_KhungGio_ThoiLuong CHECK (thoi_luong_phut > 0)
);
GO

/* =========================================================
   8. LỊCH LÀM VIỆC
   ========================================================= */

CREATE TABLE Lich_lam_viec (
    ma_lich_lam INT IDENTITY(1,1) PRIMARY KEY,
    ngay_lam_viec DATE NOT NULL,
    gio_bat_dau TIME NOT NULL,
    gio_ket_thuc TIME NOT NULL,
    ca_lam NVARCHAR(20) NOT NULL,
    ma_bac_si VARCHAR(10) NOT NULL,
    ma_phong VARCHAR(10) NOT NULL,

    CONSTRAINT FK_LLV_BacSi
        FOREIGN KEY (ma_bac_si) REFERENCES Bac_si(ma_bac_si),

    CONSTRAINT FK_LLV_Phong
        FOREIGN KEY (ma_phong) REFERENCES Phong_kham(ma_phong),

    CONSTRAINT CHK_LLV_GioHopLe
        CHECK (gio_ket_thuc > gio_bat_dau),

    CONSTRAINT CHK_LLV_CaLam
        CHECK (ca_lam IN (N'Ca sáng', N'Ca chiều'))
);
GO

CREATE UNIQUE INDEX UIX_LLV_BacSi_Ngay_Ca
ON Lich_lam_viec(ma_bac_si, ngay_lam_viec, ca_lam);
GO

CREATE UNIQUE INDEX UIX_LLV_Phong_Ngay_Ca
ON Lich_lam_viec(ma_phong, ngay_lam_viec, ca_lam);
GO

/* =========================================================
   9. LỊCH HẸN
   ========================================================= */

CREATE TABLE Lich_hen (
    ma_lich_hen VARCHAR(10) PRIMARY KEY,
    ngay_kham DATE NOT NULL,
    mo_ta_trieu_chung NVARCHAR(MAX) NULL,
    ma_tai_khoan VARCHAR(10) NOT NULL,
    ma_khung_gio VARCHAR(10) NOT NULL,
    ma_bac_si VARCHAR(10) NOT NULL,
    ma_trang_thai VARCHAR(10) NOT NULL,
    ngay_tao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ngay_cap_nhat DATETIME NULL,
    gio_bat_dau_kham TIME NOT NULL,
    gio_ket_thuc_kham TIME NOT NULL,

    FOREIGN KEY (ma_tai_khoan) REFERENCES Tai_khoan(ma_tai_khoan),
    FOREIGN KEY (ma_khung_gio) REFERENCES Khung_gio_kham(ma_khung_gio),
    FOREIGN KEY (ma_bac_si) REFERENCES Bac_si(ma_bac_si),
    FOREIGN KEY (ma_trang_thai) REFERENCES Trang_thai(ma_trang_thai),

    CONSTRAINT CHK_LichHen_GioHopLe
        CHECK (gio_ket_thuc_kham > gio_bat_dau_kham)
);
GO

CREATE UNIQUE NONCLUSTERED INDEX UIX_LichHen_KhongTrung
ON Lich_hen (ma_bac_si, ma_khung_gio, ngay_kham)
WHERE ma_trang_thai = 'TT01';
GO

/* =========================================================
   10. DỮ LIỆU CƠ BẢN
   ========================================================= */

INSERT INTO Vai_tro (ma_vai_tro, ten_vai_tro) VALUES
('VT01', N'Quản trị viên'),
('VT02', N'Bệnh nhân');
GO

INSERT INTO Trang_thai (ma_trang_thai, ten_trang_thai) VALUES
('TT01', N'Đã xác nhận'),
('TT02', N'Đã hủy'),
('TT03', N'Đã khám xong'),
('TT04', N'Chờ xác nhận');
GO

INSERT INTO Tai_khoan (ma_tai_khoan, email, mat_khau, ma_vai_tro) VALUES
('TK001', 'admin@gmail.com', '123', 'VT01');
GO

INSERT INTO Thong_tin_nguoi_dung (
    ma_nguoi_dung, ho_ten, so_dien_thoai, ma_tai_khoan
) VALUES
('ND001', N'Quản trị viên', '0900000000', 'TK001');
GO

/* =========================================================
   11. PROCEDURE: TỰ ĐỘNG CẬP NHẬT LỊCH HẸN ĐÃ KHÁM XONG
   ========================================================= */

DROP PROCEDURE IF EXISTS dbo.sp_AutoUpdateCompletedAppointments;
GO

CREATE PROCEDURE dbo.sp_AutoUpdateCompletedAppointments
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Lich_hen
    SET ma_trang_thai = 'TT03',
        ngay_cap_nhat = GETDATE()
    WHERE ma_trang_thai = 'TT01'
      AND (
            ngay_kham < CAST(GETDATE() AS DATE)
            OR (
                ngay_kham = CAST(GETDATE() AS DATE)
                AND gio_ket_thuc_kham < CAST(GETDATE() AS TIME)
            )
          );
END;
GO

/* =========================================================
   12. PROCEDURE: TẠO LỊCH MẶC ĐỊNH CHO 1 BÁC SĨ
   Chỉ tạo từ THỨ 2 đến THỨ 6
   Gán phòng đúng theo khoa và thứ tự trong khoa
   ========================================================= */

DROP PROCEDURE IF EXISTS dbo.sp_TaoLichMacDinhChoBacSi;
GO

CREATE PROCEDURE dbo.sp_TaoLichMacDinhChoBacSi
    @ma_bac_si VARCHAR(10),
    @tu_ngay DATE,
    @so_ngay INT = 30
AS
BEGIN
    SET NOCOUNT ON;
    SET DATEFIRST 1;

    IF NOT EXISTS (
        SELECT 1
        FROM dbo.Bac_si
        WHERE ma_bac_si = @ma_bac_si
    )
    BEGIN
        RAISERROR (N'Bác sĩ không tồn tại.', 16, 1);
        RETURN;
    END

    DECLARE @ma_phong VARCHAR(10);

    ;WITH BacSiTheoKhoa AS (
        SELECT 
            ma_bac_si,
            ma_khoa,
            ROW_NUMBER() OVER (PARTITION BY ma_khoa ORDER BY ma_bac_si) AS stt_bac_si
        FROM dbo.Bac_si
    ),
    PhongTheoKhoa AS (
        SELECT 
            ma_phong,
            ma_khoa,
            ROW_NUMBER() OVER (PARTITION BY ma_khoa ORDER BY ma_phong) AS stt_phong
        FROM dbo.Phong_kham
    )
    SELECT @ma_phong = p.ma_phong
    FROM BacSiTheoKhoa b
    INNER JOIN PhongTheoKhoa p
        ON b.ma_khoa = p.ma_khoa
       AND b.stt_bac_si = p.stt_phong
    WHERE b.ma_bac_si = @ma_bac_si;

    IF @ma_phong IS NULL
    BEGIN
        RAISERROR (N'Không tìm thấy phòng phù hợp cho bác sĩ trong khoa.', 16, 1);
        RETURN;
    END

    ;WITH NgayLam AS (
        SELECT @tu_ngay AS ngay_lam_viec
        UNION ALL
        SELECT DATEADD(DAY, 1, ngay_lam_viec)
        FROM NgayLam
        WHERE ngay_lam_viec < DATEADD(DAY, @so_ngay - 1, @tu_ngay)
    )
    INSERT INTO dbo.Lich_lam_viec (
        ngay_lam_viec,
        gio_bat_dau,
        gio_ket_thuc,
        ca_lam,
        ma_bac_si,
        ma_phong
    )
    SELECT
        ngay_lam_viec,
        '07:00:00',
        '11:00:00',
        N'Ca sáng',
        @ma_bac_si,
        @ma_phong
    FROM NgayLam
    WHERE DATEPART(WEEKDAY, ngay_lam_viec) BETWEEN 1 AND 5
      AND NOT EXISTS (
          SELECT 1
          FROM dbo.Lich_lam_viec llv
          WHERE llv.ma_bac_si = @ma_bac_si
            AND llv.ngay_lam_viec = NgayLam.ngay_lam_viec
            AND llv.ca_lam = N'Ca sáng'
      )

    UNION ALL

    SELECT
        ngay_lam_viec,
        '13:30:00',
        '16:30:00',
        N'Ca chiều',
        @ma_bac_si,
        @ma_phong
    FROM NgayLam
    WHERE DATEPART(WEEKDAY, ngay_lam_viec) BETWEEN 1 AND 5
      AND NOT EXISTS (
          SELECT 1
          FROM dbo.Lich_lam_viec llv
          WHERE llv.ma_bac_si = @ma_bac_si
            AND llv.ngay_lam_viec = NgayLam.ngay_lam_viec
            AND llv.ca_lam = N'Ca chiều'
      )
    OPTION (MAXRECURSION 1000);
END;
GO

/* =========================================================
   13. PROCEDURE: TẠO LỊCH MẶC ĐỊNH CHO TẤT CẢ BÁC SĨ
   ========================================================= */

DROP PROCEDURE IF EXISTS dbo.sp_TaoLichMacDinhChoTatCaBacSi;
GO

CREATE PROCEDURE dbo.sp_TaoLichMacDinhChoTatCaBacSi
    @tu_ngay DATE,
    @so_ngay INT = 30
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ma_bac_si VARCHAR(10);

    DECLARE cur CURSOR FOR
        SELECT ma_bac_si
        FROM dbo.Bac_si
        ORDER BY ma_bac_si;

    OPEN cur;
    FETCH NEXT FROM cur INTO @ma_bac_si;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC dbo.sp_TaoLichMacDinhChoBacSi
            @ma_bac_si = @ma_bac_si,
            @tu_ngay = @tu_ngay,
            @so_ngay = @so_ngay;

        FETCH NEXT FROM cur INTO @ma_bac_si;
    END

    CLOSE cur;
    DEALLOCATE cur;
END;
GO

/* =========================================================
   14. PROCEDURE: ĐỔI GIỜ LÀM BÁC SĨ THEO NGÀY HIỆU LỰC
   Chỉ tạo từ THỨ 2 đến THỨ 6
   Gán phòng đúng theo khoa và thứ tự trong khoa
   ========================================================= */

DROP PROCEDURE IF EXISTS dbo.sp_DoiGioLamBacSi;
GO

CREATE PROCEDURE dbo.sp_DoiGioLamBacSi
    @ma_cau_hinh VARCHAR(10),
    @ma_bac_si VARCHAR(10),
    @ngay_hieu_luc DATE,
    @gio_sang_bat_dau TIME,
    @gio_sang_ket_thuc TIME,
    @gio_chieu_bat_dau TIME,
    @gio_chieu_ket_thuc TIME,
    @so_ngay_tao_lich INT = 30,
    @ghi_chu NVARCHAR(255) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET DATEFIRST 1;

    IF NOT EXISTS (
        SELECT 1
        FROM dbo.Bac_si
        WHERE ma_bac_si = @ma_bac_si
    )
    BEGIN
        RAISERROR (N'Bác sĩ không tồn tại.', 16, 1);
        RETURN;
    END

    IF EXISTS (
        SELECT 1
        FROM dbo.Cau_hinh_gio_lam_bac_si
        WHERE ma_cau_hinh = @ma_cau_hinh
    )
    BEGIN
        RAISERROR (N'Mã cấu hình đã tồn tại.', 16, 1);
        RETURN;
    END

    IF @ngay_hieu_luc < CAST(GETDATE() AS DATE)
    BEGIN
        RAISERROR (N'Ngày hiệu lực không được ở quá khứ.', 16, 1);
        RETURN;
    END

    IF @gio_sang_ket_thuc <= @gio_sang_bat_dau
    BEGIN
        RAISERROR (N'Giờ ca sáng không hợp lệ.', 16, 1);
        RETURN;
    END

    IF @gio_chieu_ket_thuc <= @gio_chieu_bat_dau
    BEGIN
        RAISERROR (N'Giờ ca chiều không hợp lệ.', 16, 1);
        RETURN;
    END

    IF @gio_sang_ket_thuc > @gio_chieu_bat_dau
    BEGIN
        RAISERROR (N'Ca sáng và ca chiều bị chồng giờ.', 16, 1);
        RETURN;
    END

    IF EXISTS (
        SELECT 1
        FROM dbo.Lich_hen
        WHERE ma_bac_si = @ma_bac_si
          AND ma_trang_thai = 'TT01'
          AND ngay_kham >= @ngay_hieu_luc
          AND NOT (
                (gio_bat_dau_kham >= @gio_sang_bat_dau AND gio_ket_thuc_kham <= @gio_sang_ket_thuc)
                OR
                (gio_bat_dau_kham >= @gio_chieu_bat_dau AND gio_ket_thuc_kham <= @gio_chieu_ket_thuc)
          )
    )
    BEGIN
        RAISERROR (N'Có lịch hẹn đã xác nhận không còn phù hợp với giờ làm mới.', 16, 1);
        RETURN;
    END

    UPDATE dbo.Cau_hinh_gio_lam_bac_si
    SET trang_thai = N'Hết hiệu lực',
        ngay_cap_nhat = GETDATE()
    WHERE ma_bac_si = @ma_bac_si
      AND trang_thai = N'Đang áp dụng';

    INSERT INTO dbo.Cau_hinh_gio_lam_bac_si (
        ma_cau_hinh,
        ma_bac_si,
        ngay_hieu_luc,
        gio_sang_bat_dau,
        gio_sang_ket_thuc,
        gio_chieu_bat_dau,
        gio_chieu_ket_thuc,
        trang_thai,
        ngay_tao,
        ghi_chu
    )
    VALUES (
        @ma_cau_hinh,
        @ma_bac_si,
        @ngay_hieu_luc,
        @gio_sang_bat_dau,
        @gio_sang_ket_thuc,
        @gio_chieu_bat_dau,
        @gio_chieu_ket_thuc,
        N'Đang áp dụng',
        GETDATE(),
        @ghi_chu
    );

    DECLARE @ma_phong VARCHAR(10);

    ;WITH BacSiTheoKhoa AS (
        SELECT 
            ma_bac_si,
            ma_khoa,
            ROW_NUMBER() OVER (PARTITION BY ma_khoa ORDER BY ma_bac_si) AS stt_bac_si
        FROM dbo.Bac_si
    ),
    PhongTheoKhoa AS (
        SELECT 
            ma_phong,
            ma_khoa,
            ROW_NUMBER() OVER (PARTITION BY ma_khoa ORDER BY ma_phong) AS stt_phong
        FROM dbo.Phong_kham
    )
    SELECT @ma_phong = p.ma_phong
    FROM BacSiTheoKhoa b
    INNER JOIN PhongTheoKhoa p
        ON b.ma_khoa = p.ma_khoa
       AND b.stt_bac_si = p.stt_phong
    WHERE b.ma_bac_si = @ma_bac_si;

    IF @ma_phong IS NULL
    BEGIN
        RAISERROR (N'Không tìm thấy phòng phù hợp cho bác sĩ trong khoa.', 16, 1);
        RETURN;
    END

    DELETE FROM dbo.Lich_lam_viec
    WHERE ma_bac_si = @ma_bac_si
      AND ngay_lam_viec >= @ngay_hieu_luc;

    ;WITH NgayLam AS (
        SELECT @ngay_hieu_luc AS ngay_lam_viec
        UNION ALL
        SELECT DATEADD(DAY, 1, ngay_lam_viec)
        FROM NgayLam
        WHERE ngay_lam_viec < DATEADD(DAY, @so_ngay_tao_lich - 1, @ngay_hieu_luc)
    )
    INSERT INTO dbo.Lich_lam_viec (
        ngay_lam_viec,
        gio_bat_dau,
        gio_ket_thuc,
        ca_lam,
        ma_bac_si,
        ma_phong
    )
    SELECT
        ngay_lam_viec,
        @gio_sang_bat_dau,
        @gio_sang_ket_thuc,
        N'Ca sáng',
        @ma_bac_si,
        @ma_phong
    FROM NgayLam
    WHERE DATEPART(WEEKDAY, ngay_lam_viec) BETWEEN 1 AND 5

    UNION ALL

    SELECT
        ngay_lam_viec,
        @gio_chieu_bat_dau,
        @gio_chieu_ket_thuc,
        N'Ca chiều',
        @ma_bac_si,
        @ma_phong
    FROM NgayLam
    WHERE DATEPART(WEEKDAY, ngay_lam_viec) BETWEEN 1 AND 5
    OPTION (MAXRECURSION 1000);
END;
GO

EXEC dbo.sp_TaoLichMacDinhChoTatCaBacSi
    @tu_ngay = '2026-04-08',
    @so_ngay = 30;
GO

SELECT COUNT(*) AS tong_lich
FROM dbo.Lich_lam_viec;
GO

SELECT TOP 50 *
FROM dbo.Lich_lam_viec
ORDER BY ma_bac_si, ngay_lam_viec, ca_lam;
GO